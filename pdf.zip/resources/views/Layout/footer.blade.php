<script src="{{ asset('js/app.js') }}" type="text/js"></script>
</body>
</html>