<script src="<?php echo e(asset('js/app.js')); ?>" type="text/js"></script>
</body>
</html><?php /**PATH F:\xampp\htdocs\q-clock\pdf\resources\views/Layout/footer.blade.php ENDPATH**/ ?>