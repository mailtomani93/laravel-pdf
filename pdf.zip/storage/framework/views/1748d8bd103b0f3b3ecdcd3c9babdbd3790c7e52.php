<?php echo $__env->make('Layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mt-5">
        <div class="row">
            <div class="col-md-3">
                <img src="<?php echo e(URL::to('assets/ocs-logo.png')); ?>" width="200" />
            </div>
            <div class="col-md-6">
            <h2 class="text-center mb-3">O Clock Software Employee List</h2>
            </div>
            <div class="col-md-3">
                <div class="d-flex justify-content-end mb-4">
                <a class="btn btn-primary mr-10" href="<?php echo e(URL::to('/create')); ?>">Add New</a>
                &nbsp;&nbsp;
                <a class="btn btn-primary" href="<?php echo e(URL::to('/employee/pdf')); ?>">Export to PDF</a>
                </div>
            </div>
        </div>
        <table class="table table-bordered mb-5">
            <thead>
                <tr class="table-danger">
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">DOB</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $employee ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($data->id); ?></th>
                    <td><?php echo e($data->name); ?></td>
                    <td><?php echo e($data->email); ?></td>
                    <td><?php echo e($data->phone_number); ?></td>
                    <td><?php echo e($data->dob); ?></td>
                    <td>
                        <a class="btn btn-primary text-white" href="<?php echo e(url('/edit/'.$data->id)); ?>">
                            Edit
                        </a>
                        <form id="delete-form-<?php echo e($data->id); ?>" action="<?php echo e(url('/destroy/'.$data->id)); ?>" method="post" style=" display: inline-block;">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger text-white" type="submit">
                                Delete
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <?php echo $__env->make('Layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\q-clock\pdf\resources\views/employee.blade.php ENDPATH**/ ?>